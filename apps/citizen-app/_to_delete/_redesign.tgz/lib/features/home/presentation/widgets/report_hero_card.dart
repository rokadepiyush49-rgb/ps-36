import 'package:flutter/material.dart';

import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/janmaang_typography.dart';
import '../../../../core/theme/motion.dart';
import '../../../../shared/models/demand_enums.dart';
import '../../../../shared/widgets/jm_card.dart';

/// The hero card on Home: the question, the dominant voice action, and the
/// three secondary entry points beneath it.
///
/// Voice is deliberately the largest target on the screen. It is the only
/// route into the product that does not require literacy in a script, and the
/// hierarchy here says so — everything else is a 12px-radius outline tile.
class ReportHeroCard extends StatelessWidget {
  const ReportHeroCard({super.key, required this.onStartReport});

  final void Function(ReportChannel channel) onStartReport;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return JmCard(
      padding: const EdgeInsets.all(Insets.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            'What does your community need?',
            style:
                JanMaangTypography.headlineSm.copyWith(color: scheme.onSurface),
          ),
          const SizedBox(height: Insets.xs),
          Text(
            'Speak in your own language. We will do the rest.',
            style: JanMaangTypography.bodySm
                .copyWith(color: scheme.onSurfaceVariant),
          ),
          const SizedBox(height: Insets.lg),
          _VoiceAction(onTap: () => onStartReport(ReportChannel.voice)),
          const SizedBox(height: Insets.md),
          Row(
            children: <Widget>[
              Expanded(
                child: _SecondaryAction(
                  icon: Icons.keyboard_outlined,
                  label: 'Type request',
                  onTap: () => onStartReport(ReportChannel.text),
                ),
              ),
              const SizedBox(width: Insets.sm + Insets.xs),
              Expanded(
                child: _SecondaryAction(
                  icon: Icons.photo_camera_outlined,
                  label: 'Upload photo',
                  onTap: () => onStartReport(ReportChannel.photo),
                ),
              ),
              const SizedBox(width: Insets.sm + Insets.xs),
              Expanded(
                child: _SecondaryAction(
                  icon: Icons.my_location_outlined,
                  label: 'Use location',
                  onTap: () => onStartReport(ReportChannel.location),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// The dominant action.
///
/// Press feedback comes from the InkWell's own highlight rather than a second
/// gesture detector wrapped around it — two tap recognisers in one arena is a
/// coin flip over which one fires.
class _VoiceAction extends StatefulWidget {
  const _VoiceAction({required this.onTap});

  final VoidCallback onTap;

  @override
  State<_VoiceAction> createState() => _VoiceActionState();
}

class _VoiceActionState extends State<_VoiceAction> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final reduced = Motion.reduced(context);

    return Semantics(
      button: true,
      label: 'Report by voice',
      excludeSemantics: true,
      child: AnimatedScale(
        scale: reduced || !_pressed ? 1.0 : 0.98,
        duration: Motion.fast,
        curve: Motion.curve,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: scheme.primary,
            borderRadius: BorderRadius.circular(Corners.lg),
            boxShadow: Shadows.level2,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(Corners.lg),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: widget.onTap,
                onHighlightChanged: (value) =>
                    setState(() => _pressed = value),
                child: Container(
                  width: double.infinity,
                  constraints: const BoxConstraints(minHeight: 168),
                  padding: const EdgeInsets.symmetric(vertical: Insets.lg),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        width: 64,
                        height: 64,
                        decoration: BoxDecoration(
                          color: scheme.onPrimary.withValues(alpha: 0.14),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: scheme.onPrimary.withValues(alpha: 0.22),
                          ),
                        ),
                        child: Icon(
                          Icons.mic_rounded,
                          size: 32,
                          color: scheme.onPrimary,
                        ),
                      ),
                      const SizedBox(height: Insets.md),
                      Text(
                        'Report by Voice',
                        style: JanMaangTypography.headlineSm
                            .copyWith(color: scheme.onPrimary),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Tap and speak',
                        style: JanMaangTypography.bodySm.copyWith(
                          color: scheme.onPrimary.withValues(alpha: 0.76),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _SecondaryAction extends StatefulWidget {
  const _SecondaryAction({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  State<_SecondaryAction> createState() => _SecondaryActionState();
}

class _SecondaryActionState extends State<_SecondaryAction> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: Material(
        color: _hovered ? scheme.primaryFixed : scheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(Corners.base),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: widget.onTap,
          child: AnimatedContainer(
            duration: Motion.fast,
            curve: Motion.curve,
            decoration: BoxDecoration(
              border: Border.all(
                color: _hovered ? scheme.primary : scheme.outlineVariant,
              ),
              borderRadius: BorderRadius.circular(Corners.base),
            ),
            constraints: const BoxConstraints(minHeight: 84),
            padding: const EdgeInsets.symmetric(
              vertical: Insets.md,
              horizontal: Insets.xs,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(
                  widget.icon,
                  size: 22,
                  color: _hovered ? scheme.primary : scheme.onSurfaceVariant,
                ),
                const SizedBox(height: Insets.sm),
                Text(
                  widget.label,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: JanMaangTypography.labelMd
                      .copyWith(color: scheme.onSurface),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
