import 'package:flutter/material.dart';

import '../../core/theme/app_spacing.dart';
import '../../core/theme/janmaang_typography.dart';
import '../../core/theme/motion.dart';

/// The floating bottom navigation.
///
/// Five destinations — Home · Track · Report · Ranks · Ledger — on a rounded
/// bar that sits above the content rather than being welded to the bottom
/// edge. Report is the dominant action: a raised primary circle that breaks
/// the top of the bar, ringed in the bar's own colour so it reads as sitting
/// in front of it.
///
/// The selected destination is marked three ways at once — a pill that slides
/// between slots, a filled rather than outlined icon, and a navy label — so
/// the state survives greyscale, colour-blindness and a bright screen outdoors.
/// Labels are always visible; an icon alone is never the only signal.
class JmBottomNav extends StatelessWidget {
  const JmBottomNav({
    super.key,
    required this.currentIndex,
    required this.onDestinationSelected,
  });

  final int currentIndex;
  final ValueChanged<int> onDestinationSelected;

  /// Height of the bar itself. The raised action overhangs it.
  static const barHeight = 62.0;

  /// Height of the sliding indicator pill.
  static const _pillHeight = 34.0;

  static const destinations = <JmNavDestination>[
    JmNavDestination(
      label: 'Home',
      icon: Icons.home_outlined,
      selectedIcon: Icons.home_rounded,
    ),
    JmNavDestination(
      label: 'Track',
      icon: Icons.insights_outlined,
      selectedIcon: Icons.insights_rounded,
    ),
    JmNavDestination(
      label: 'Report',
      icon: Icons.mic_none_rounded,
      selectedIcon: Icons.mic_rounded,
      raised: true,
    ),
    JmNavDestination(
      label: 'Ranks',
      icon: Icons.emoji_events_outlined,
      selectedIcon: Icons.emoji_events_rounded,
    ),
    JmNavDestination(
      label: 'Ledger',
      icon: Icons.receipt_long_outlined,
      selectedIcon: Icons.receipt_long_rounded,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final reduced = Motion.reduced(context);

    // On a wide window the bar would stretch to absurd proportions, so it is
    // capped and centred instead.
    final width = MediaQuery.sizeOf(context).width;
    final wide = width >= Breakpoints.medium;
    final horizontalMargin = wide ? (width - 520) / 2 : Insets.md;

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          horizontalMargin < Insets.md ? Insets.md : horizontalMargin,
          0,
          horizontalMargin < Insets.md ? Insets.md : horizontalMargin,
          Insets.sm + Insets.xs,
        ),
        child: SizedBox(
          height: barHeight,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final slot = constraints.maxWidth / destinations.length;
              final pillWidth = slot - Insets.md;
              final index = currentIndex < 0
                  ? 0
                  : currentIndex > destinations.length - 1
                      ? destinations.length - 1
                      : currentIndex;
              final selectedIsRaised = destinations[index].raised;

              return Stack(
                clipBehavior: Clip.none,
                children: <Widget>[
                  // The bar itself.
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: scheme.surfaceContainerLowest,
                        borderRadius: BorderRadius.circular(Corners.xl),
                        border: Border.all(color: scheme.outlineVariant),
                        boxShadow: Shadows.level3,
                      ),
                    ),
                  ),

                  // The indicator, sliding between slots rather than fading in
                  // and out of each one — the movement is what tells you where
                  // you came from.
                  AnimatedPositioned(
                    duration: reduced ? Duration.zero : Motion.medium,
                    curve: Motion.curve,
                    left: slot * index + Insets.sm,
                    top: Insets.xs + 2,
                    width: pillWidth < 0 ? 0 : pillWidth,
                    height: _pillHeight,
                    child: AnimatedOpacity(
                      duration: reduced ? Duration.zero : Motion.fast,
                      opacity: selectedIsRaised ? 0 : 1,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: scheme.primaryFixed,
                          borderRadius: BorderRadius.circular(Corners.pill),
                        ),
                      ),
                    ),
                  ),

                  // The ink has to land on a Material above the bar's own
                  // background, or the splash paints behind it.
                  Positioned.fill(
                    child: Material(
                      color: Colors.transparent,
                      child: Row(
                        children: <Widget>[
                          for (var i = 0; i < destinations.length; i++)
                            Expanded(
                              child: _NavItem(
                                destination: destinations[i],
                                selected: i == currentIndex,
                                onTap: () => onDestinationSelected(i),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class JmNavDestination {
  const JmNavDestination({
    required this.label,
    required this.icon,
    required this.selectedIcon,
    this.raised = false,
  });

  final String label;
  final IconData icon;
  final IconData selectedIcon;

  /// Report is drawn as an elevated circle breaking the top of the bar.
  final bool raised;
}

/// One destination.
///
/// Tapping runs a single short scale pulse on the icon — 1.0 → 1.10 → 1.0 —
/// which acknowledges the tap on a screen where the destination change itself
/// may take a moment. It fires once and settles; nothing here loops.
class _NavItem extends StatefulWidget {
  const _NavItem({
    required this.destination,
    required this.selected,
    required this.onTap,
  });

  final JmNavDestination destination;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_NavItem> createState() => _NavItemState();
}

class _NavItemState extends State<_NavItem>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 260),
  );

  late final Animation<double> _scale = TweenSequence<double>(
    <TweenSequenceItem<double>>[
      TweenSequenceItem<double>(
        tween: Tween<double>(begin: 1, end: 1.10)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 40,
      ),
      TweenSequenceItem<double>(
        tween: Tween<double>(begin: 1.10, end: 1)
            .chain(CurveTween(curve: Curves.easeOutCubic)),
        weight: 60,
      ),
    ],
  ).animate(_pulse);

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  void _handleTap() {
    if (!Motion.reduced(context)) {
      _pulse.forward(from: 0);
    }
    widget.onTap();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final d = widget.destination;
    final reduced = Motion.reduced(context);

    final icon = ScaleTransition(
      scale: _scale,
      child: Icon(
        widget.selected ? d.selectedIcon : d.icon,
        size: 23,
        color: d.raised
            ? scheme.onPrimary
            : widget.selected
                ? scheme.onPrimaryFixed
                : scheme.onSurfaceVariant,
      ),
    );

    final label = AnimatedDefaultTextStyle(
      duration: reduced ? Duration.zero : Motion.fast,
      curve: Motion.curve,
      style: JanMaangTypography.withWeight(
        JanMaangTypography.navLabel,
        widget.selected ? FontWeight.w700 : FontWeight.w600,
      ).copyWith(
        color: widget.selected ? scheme.primary : scheme.onSurfaceVariant,
      ),
      child: Text(
        d.label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        textAlign: TextAlign.center,
      ),
    );

    if (d.raised) {
      return Semantics(
        button: true,
        selected: widget.selected,
        label: '${d.label} — report a need',
        excludeSemantics: true,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _handleTap,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.bottomCenter,
            children: <Widget>[
              Positioned(
                bottom: 20,
                child: Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: scheme.primary,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: scheme.surfaceContainerLowest,
                      width: 4,
                    ),
                    boxShadow: Shadows.level2,
                  ),
                  child: Center(child: icon),
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: Insets.sm,
                child: label,
              ),
            ],
          ),
        ),
      );
    }

    return Semantics(
      button: true,
      selected: widget.selected,
      label: d.label,
      excludeSemantics: true,
      child: InkWell(
        onTap: _handleTap,
        customBorder: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(Corners.pill),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: Insets.xs),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                height: JmBottomNav._pillHeight,
                child: Center(child: icon),
              ),
              const SizedBox(height: Insets.xxs),
              label,
            ],
          ),
        ),
      ),
    );
  }
}
