import 'package:flutter/widgets.dart';

/// Spacing and shape tokens.
///
/// Everything is a multiple of the 4px baseline grid that gives the interface
/// its vertical rhythm.
abstract final class Insets {
  static const double xxs = 2;
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 48;

  static const double gutter = 24;
  static const double marginMobile = 16;
  static const double marginDesktop = 32;
  static const double containerMax = 1280;

  /// Clearance a scrolling tab body must leave under its last element so the
  /// floating navigation bar never covers content. Bar height + its margin +
  /// the raised Report button's overhang.
  static const double navClearance = 116;
}

/// Shape language.
///
/// Softer than a strict institutional grid but still square-shouldered enough
/// to read as public infrastructure rather than a consumer app: cards land at
/// 20px, containers and sheets at 28px, and pills are reserved for chips,
/// filters and the navigation indicator — never for primary buttons.
abstract final class Corners {
  /// Checkboxes, small tags, inline pips.
  static const double sm = 8;

  /// Buttons, input fields, small controls.
  static const double base = 12;

  /// The standard card.
  static const double lg = 20;

  /// Sheets, modals, the floating navigation bar, hero containers.
  static const double xl = 28;

  /// Chips, filters, status badges, the navigation indicator.
  static const double pill = 999;
}

/// Elevation recipe.
///
/// Depth comes from a hairline plus a wide, very low-opacity shadow tinted
/// with the brand navy — never from a dark drop shadow. Three levels only, so
/// two adjacent surfaces are never ambiguous.
abstract final class Shadows {
  /// Resting card. Barely there; the hairline does most of the work.
  static const List<BoxShadow> level1 = <BoxShadow>[
    BoxShadow(
      color: Color(0x0A16325F),
      offset: Offset(0, 1),
      blurRadius: 2,
    ),
    BoxShadow(
      color: Color(0x0F16325F),
      offset: Offset(0, 4),
      blurRadius: 12,
      spreadRadius: -4,
    ),
  ];

  /// Hovered or emphasised card, the raised Report action.
  static const List<BoxShadow> level2 = <BoxShadow>[
    BoxShadow(
      color: Color(0x1416325F),
      offset: Offset(0, 6),
      blurRadius: 20,
      spreadRadius: -6,
    ),
  ];

  /// The floating navigation bar, popovers, map callouts.
  static const List<BoxShadow> level3 = <BoxShadow>[
    BoxShadow(
      color: Color(0x1F16325F),
      offset: Offset(0, 10),
      blurRadius: 32,
      spreadRadius: -8,
    ),
    BoxShadow(
      color: Color(0x0A16325F),
      offset: Offset(0, 2),
      blurRadius: 6,
    ),
  ];
}

/// Minimum interactive sizes. Below these a control fails the accessibility
/// review, whatever it looks like.
abstract final class Hit {
  /// Absolute floor for any tappable target.
  static const double min = 48;

  /// Standard control height — buttons, inputs, filter chips.
  static const double control = 52;

  /// Dense controls where 52 would crowd the layout (chips inside a scroller).
  static const double controlDense = 44;
}

/// Layout breakpoint. Below this the designs collapse the side nav into the
/// bottom navigation bar and stack the bento grid into a single column.
abstract final class Breakpoints {
  static const double medium = 768;
  static const double expanded = 1024;
}
